The code in this archive is an implementation of a platform independent
multithreading library. The code is a minimally modified subset of classes from
the Insight Toolkit (ITK - www.itk.org).

The motivation for creating this library outside of ITK is to provide the
capability for platform independent multi-threading without the need to install
the complete toolkit.
